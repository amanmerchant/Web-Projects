 document.addEventListener('DOMContentLoaded', function () {
  const searchInput = document.getElementById('course-search');
  const courseItems = document.querySelectorAll('.course-item');

  searchInput.addEventListener('input', function () {
    const query = this.value.toLowerCase().trim();
    courseItems.forEach(item => {
      const keywords = item.dataset.keywords.toLowerCase();
      if (keywords.includes(query)) {
        item.style.display = 'block';
      } else {
        item.style.display = 'none';
      }
    });
  });
});
    
            // Navbar background change on scroll
            $(window).scroll(function() {
                if ($(this).scrollTop() > 50) {
                    $('.navbar').addClass('scrolled');
                } else {
                    $('.navbar').removeClass('scrolled');
                }
            });
            
            // Load courses from Django backend (simulated)
            function loadCourses() {
                // In a real implementation, this would be an AJAX call to your Django backend
                // $.get('/api/courses/', function(data) {
                //     // Process and display courses
                // });
                
                // For demo purposes, we're using static data
                console.log("Loading courses from backend...");
            }
            
            loadCourses();
    