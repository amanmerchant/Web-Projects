from django.contrib import admin
from .models import Course, Contact,CourseApplication

admin.site.register(Course)



@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    readonly_fields = ['name', 'email', 'message', 'phonenumber','created_at']

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return True



@admin.register(CourseApplication)
class CourseApplicationAdmin(admin.ModelAdmin):
    readonly_fields = [field.name for field in CourseApplication._meta.fields]
    list_display = ('user', 'applicant_name', 'email', 'phone_number', 'course', 'applied_at')
    list_filter = ('course', 'applied_at')
    search_fields = ('applicant_name', 'email', 'phone_number')

    def has_add_permission(self, request):
        return False  # Disables "Add" button

    def has_change_permission(self, request, obj=None):
        return False  # Disables editing

    # def has_delete_permission(self, request, obj=None):
    #     return False  # Disables delete

