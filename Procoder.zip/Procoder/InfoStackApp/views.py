from django.shortcuts import render,redirect,get_object_or_404
from django.http import JsonResponse
from .models import Course, Contact,CourseApplication
from django.views.decorators.csrf import csrf_exempt
import json
from math import ceil
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count

def home(request):
    allCourses = []
    cat_courses = Course.objects.values('category', 'id')
    cats = {item['category'] for item in cat_courses}

    course_app_counts = CourseApplication.objects.values('course') \
        .annotate(app_count=Count('id'))

    app_count_dict = {item['course']: item['app_count'] for item in course_app_counts}

    max_applied = max(app_count_dict.values(), default=0)

    for cat in cats:
        courses = Course.objects.filter(category=cat, is_active=True)

        for course in courses:
            count = app_count_dict.get(course.id, 0)
            course.app_count = count
            if count == 0:
                course.badge = 'New'
            elif count == max_applied:
                course.badge = 'Trending'
            else:
                course.badge = 'Most Applied'

        n = len(courses)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allCourses.append([courses, range(1, nSlides + 1), nSlides])

    params = {'allCourses': allCourses}
    return render(request, "base.html", params)

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        number = request.POST.get('phonenumber')
        message = request.POST.get('message')

        # Contact.objects.create(
        #     name=name,
        #     email=email,
        #     phonenumber=number,
        #     message=message
        # )
        myquery=Contact(name=name,email=email,phonenumber=number,message=message)
        myquery.save()
        messages.success(request, "Your message has been sent successfully!")
        return redirect('contact')

    return render(request, 'base.html')



@login_required(login_url='/login/')
def apply_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    success = False

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')

        CourseApplication.objects.create(
            user=request.user,  # <-- store the user
            course=course,
            applicant_name=name,
            email=email,
            phone_number=phone
        )
        success = True

    return render(request, 'form.html', {
        'course': course,
        'success': success
    })


def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Get user using email (since Django's default authentication uses username)
        try:
            user_obj = User.objects.get(email=email)
            user = authenticate(request, username=user_obj.username, password=password)
        except User.DoesNotExist:
            user = None

        if user is not None:
            login(request, user)
            # messages.success(request, "Logged in successfully!")
            return redirect('home')  # or dashboard
        else:
            messages.error(request, "Invalid email or password")

    return render(request, 'Authentication/login.html')

def logout_view(request):
    logout(request)
    return redirect('home')




from django.contrib.auth.models import User


def signup_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password != confirm_password:
            messages.error(request, 'Passwords do not match!')
            return redirect('signup')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists!')
            return redirect('signup')

        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered!')
            return redirect('signup')

        # Create user
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()

        # Log the user in after signup
        login(request, user)
        messages.success(request, 'Account created and logged in successfully!')
        return redirect('home')

    return render(request, 'Authentication/signup.html')



@login_required(login_url='/login/')
def dashboard(request):
    applications = CourseApplication.objects.filter(user=request.user)
    return render(request, 'dashboard.html', {'applications': applications})
