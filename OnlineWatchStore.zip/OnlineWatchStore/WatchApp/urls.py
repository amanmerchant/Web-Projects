from django.urls import path
from WatchApp import views
from django.views.decorators.csrf import csrf_exempt
from .views import wishlist_view, toggle_wishlist, fetch_wishlist  
urlpatterns = [
    path('', views.home, name='home'),
    path('contact/', views.contact, name='contact'),
    path('cart/', views.cart, name='cart'),
    path('forget/', views.forget, name='forget'),
    path('checkout/', views.checkout, name="checkout"),
    path('about/', views.about, name="about"),
    path('privacy/', views.privacy, name="privacy"),
    path('orders/', views.orders, name="orders"),
    path('wishlist/', wishlist_view, name="wishlist"),
    path('address/', views.address, name="address"), 

    # Wishlist AJAX Endpoints
    path("wishlist/toggle/", toggle_wishlist, name="toggle_wishlist"),
    path("wishlist/fetch/", fetch_wishlist, name="fetch_wishlist"),
]
