from django.shortcuts import render,redirect
from WatchApp.models import Contact,Product,OrderUpdate,Orders,Wishlist
from django.contrib import messages
from math import ceil
from django.conf import settings
import json
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(request):
    allProds = []
    catprods = Product.objects.values('category','id')
    print(catprods)
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod= Product.objects.filter(category=cat)
        n=len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])

    params= {'allProds':allProds}

    return render(request,"index.html",params)



def contact(request):
    if request.method=="POST":  
        name=request.POST.get("name")
        email=request.POST.get("email")
        number=request.POST.get("phonenumber")
        desc=request.POST.get("description")
        myquery=Contact(name=name,email=email,phonenumber=number,desc=desc)
        myquery.save()
        messages.info(request,'we will reply u soon...')
    return render(request,"contact.html")

def cart(request):
    return render(request,"cart.html")

def about(request):
    return render(request,"about.html")

def forget(request):
    return render(request,"forget.html")

def privacy(request):
    return render(request,"privacy.html")
def wishlist(request):
    return render(request,"wishlist.html")
def orders(request):
    return render(request,"orders.html")
def address(request):
    return render(request,"address.html")




import razorpay
def checkout(request):
    if not request.user.is_authenticated:
        messages.warning(request, "Login & Try Again")
        return redirect('/auth/login')

    client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

    if request.method == "POST":
        try:
            razorpay_payment_id = request.POST.get('razorpay_payment_id', None)
            if not razorpay_payment_id:
                messages.error(request, "Payment Failed! Please try again.")
                return render(request, 'checkout.html', {'key': settings.RAZORPAY_KEY_ID})

            items_json = request.POST.get('itemsJson', '')  # Retrieve JSON string

            try:
                items_json = json.loads(items_json)  # Convert to Python dict
            except json.JSONDecodeError:
                messages.error(request, "Invalid cart data. Please refresh and try again.")
                return render(request, 'checkout.html', {'key': settings.RAZORPAY_KEY_ID})

            name = request.POST.get('name', '')
            amount = request.POST.get('amt', '')
            email = request.user.email
            address = request.POST.get('address', '')
            city = request.POST.get('city', '')
            state = request.POST.get('state', '')
            zip_code = request.POST.get('zip_code', '')
            phone = request.POST.get('phone', '')

            order = Orders(
                items_json=json.dumps(items_json),  # Store as JSON string
                name=name,
                amount=amount,
                email=email,
                address=address,
                city=city,
                state=state,
                zip_code=zip_code,
                phone=phone,
                razorpay_payment_id=razorpay_payment_id,
                paymentstatus="Paid"
            )
            order.save()

            update = OrderUpdate(order_id=order.order_id, update_desc="The order has been placed")
            update.save()

            messages.success(request, "Your order has been placed successfully!")
            return redirect('/checkout')

        except Exception as e:
            messages.error(request, f"Payment Error: {e}")
            return render(request, 'checkout.html', {'key': settings.RAZORPAY_KEY_ID})

    return render(request, 'checkout.html', {'key': settings.RAZORPAY_KEY_ID})

from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404

@login_required
def wishlist_view(request):
    return render(request, "wishlist.html")  # Ensure this template exists

@login_required
def toggle_wishlist(request):
    if request.method == "POST":
        product_id = request.POST.get("product_id")
        product = get_object_or_404(Product, id=product_id)
        
        wishlist_item, created = Wishlist.objects.get_or_create(user=request.user, product=product)
        
        if not created:  
            wishlist_item.delete()
            return JsonResponse({"status": "removed", "message": "Removed from Wishlist"})
        
        return JsonResponse({"status": "added", "message": "Added to Wishlist"})

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)





def fetch_wishlist(request):
    if request.user.is_authenticated:
        wishlist_items = Wishlist.objects.filter(user=request.user).select_related('product')
        wishlist_data = [
            {
                "id": item.product.id,
                "name": item.product.product_name,
                "image": item.product.image.url,
                "price": item.product.price,
                "desc" :item.product.desc,
                "url": item.product.get_absolute_url(),
            }
            for item in wishlist_items
        ]
        return JsonResponse({"wishlist": wishlist_data})
    else:
        return JsonResponse({"wishlist": []})

