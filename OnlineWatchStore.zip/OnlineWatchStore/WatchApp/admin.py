from django.contrib import admin
from WatchApp.models import Contact, Product, Orders, OrderUpdate,Wishlist
admin.register(Wishlist)

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    readonly_fields = ['name', 'email', 'desc', 'phonenumber','date']

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return True


@admin.register(Orders)
class OrdersAdmin(admin.ModelAdmin):
    readonly_fields = [
        'order_id', 'items_json', 'amount','razorpay_payment_id', 'name', 'email', 'address',
        'city', 'state', 'zip_code', 'paymentstatus', 'phone','date'
    ]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return True


admin.site.register(Product)
admin.site.register(OrderUpdate)
