


let scrollBtn = document.getElementById("scrollTopBtn");

window.onscroll = function () {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        scrollBtn.style.display = "block";
    } else {
        scrollBtn.style.display = "none";
    }
};

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}
//cursor
var body = document.querySelector("body");
var cursor = document.getElementById("cursor");
var a = document.querySelector("#big")

// Track mouse movement to position cursor
// document.addEventListener('mousemove', (e) => {
//     gsap.to(cursor, {
//       x: e.clientX,
//       y: e.clientY,
//       duration: 0.1,
//       ease: "back.out"
      
//     });
//   });
  
a.addEventListener("mouseenter",()=>{
    gsap.to(cursor,{
        scale:4
    })
})
a.addEventListener("mouseleave",()=>{
    gsap.to(cursor,{
        scale:1
    })
})
gsap.from("#about .container-fluid",{
    scale:0,
    opacity:0,
    duration:1,
    scrollTrigger:{
        trigger:"#about .container-fluid",
        scroller:"body",
        start:"top 100%",
        end:"top 70%",
    }
})

gsap.from("#why .container",{
    scale:0,
    opacity:0,
    duration:1,
    scrollTrigger:{
        trigger:"#why .container",
        scroller:"body",
        start:"top 100%",
        end:"top 70%",
    }
})


gsap.from("#friendly .container",{
    scale:0,
    opacity:0,
    duration:1,
    scrollTrigger:{
        trigger:"#friendly .container",
        scroller:"body",
        start:"top 100%",
        end:"top 70%",
    }
})

gsap.from("#faq .container",{
    scale:0,
    opacity:0,
    duration:1,
    scrollTrigger:{
        trigger:"#faq .container",
        scroller:"body",
        start:"top 100%",
        end:"top 70%",
    }
})





