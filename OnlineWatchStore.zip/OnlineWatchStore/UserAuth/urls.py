from django.urls import path
from UserAuth import views

urlpatterns = [
    path('login/',views.userlogin,name="userlogin"),
    path('logout/',views.userlogout,name="userlogout"),
    path('signup/',views.usersignup,name="usersignup"),

]