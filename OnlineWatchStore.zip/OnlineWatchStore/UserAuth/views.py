from django.shortcuts import render,redirect
from UserAuth import views
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

# Create your views here.
def usersignup(request):
    if request.method=="POST":
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        if password != confirm_password:
            messages.error(request,"Pass Not Match")
            return render(request,'signup.html')
        try:
            if User.objects.get(username=username):
                messages.info(request,"username has taken")
                return render(request,'signup.html')
        except Exception as identifier:
            pass
        try:
            if User.objects.get(email=email):
                messages.info(request,"email has taken")
                return render(request,'signup.html')
        except Exception as identifier:
            pass
        user = User.objects.create_user(username,email,password)
        user.save()
        messages.info(request,"User Created Successfully...")
    return render(request,"signup.html")



def userlogin(request):
    if request.method == "POST":
        email = request.POST['email']  # Use email as input for login
        userpassword = request.POST['password']

        # Authenticate user by checking both email and password
        try:
            user = User.objects.get(email=email)
            myuser = authenticate(request, username=user.username, password=userpassword)

            if myuser is not None:
                login(request, myuser)
                # messages.success(request, "Login successful...")
                return redirect("/")
            else:
                messages.error(request, "Incorrect password. Try again.")
        except User.DoesNotExist:
            messages.error(request, "User does not exist. Please sign up first.")

        return redirect('/auth/login')  # Redirect back to login page if authentication fails

    return render(request, "login.html")


def userlogout(request):
    logout(request)
    messages.info(request,"Logout Successfully...")
    return redirect('/auth/login')