from django.urls import path,include
from Profile import views
urlpatterns = [
    path('',views.index,name="index"),
]
