from django.shortcuts import render, redirect
from Profile.models import Contact, Project, Certification  # Assuming Certification model exists
from django.contrib import messages

def index(request):
    # Handle Contact Form Submission
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        number = request.POST.get("phonenumber")
        desc = request.POST.get("message")

        if name and email and number and desc:  # Ensure fields are not empty
            myquery = Contact(name=name, email=email, phonenumber=number, message=desc)
            myquery.save()
            messages.success(request, "We will reply to you soon...")
        else:
            messages.error(request, "All fields are required!")

    # Fetch Projects Data
    allProjects = []
    categories = Project.objects.values('category').distinct()
    for cat in categories:
        proj = Project.objects.filter(category=cat['category'])
        nSlides = len(proj) // 4 + (len(proj) % 4 > 0)  # Adjusted for display
        allProjects.append([proj, range(1, nSlides), nSlides])

    # Fetch Certifications/Awards Data
    allCertifications = []
    cert_categories = Certification.objects.values('category').distinct()
    for cat in cert_categories:
        certs = Certification.objects.filter(category=cat['category'])
        nSlides = len(certs) // 4 + (len(certs) % 4 > 0)  # Adjusted for display
        allCertifications.append([certs, range(1, nSlides), nSlides])

    # Render the template with both Projects and Certifications data
    return render(request, "index.html", {
        "allProjects": allProjects,
        "allCertifications": allCertifications
    })