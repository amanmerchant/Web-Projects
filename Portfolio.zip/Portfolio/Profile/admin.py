from django.contrib import admin
from Profile.models import Contact,Project,Certification

# Register your models here.
admin.site.register(Contact)
admin.site.register(Project)
admin.site.register(Certification)
