if (localStorage.getItem('cart') == null) {
    var cart = {};
} else {
    cart = JSON.parse(localStorage.getItem('cart'));
    updateCart(cart);
    document.getElementById('cart').innerHTML = Object.keys(cart).length; // Update cart count on load
}

// Add or increment item in the cart
$('.divpr').on('click', 'button.cart', function () {
    var idstr = this.id.toString();
    console.log(idstr);

    if (cart[idstr] !== undefined) {
        cart[idstr][0] += 1;
    } else {
        let name = document.getElementById('name' + idstr)?.innerHTML;
        let price = document.getElementById('price' + idstr)?.innerHTML;

        if (name && price) {
            cart[idstr] = [1, name, price];
        } else {
            console.error("Name or price not found for item:", idstr);
        }
    }

    updateCart(cart);
});

// Update the cart display
function updateCart(cart) {
    var sum = 0;
    for (let item in cart) {
        sum += cart[item][0];

        let div = document.getElementById('div' + item);
        if (div) {
            if (cart[item][0] > 0) {
                div.innerHTML =
                    `<button id="minus${item}" class="btn btn-danger minus">-</button> 
                     <span id="val${item}">${cart[item][0]}</span> 
                     <button id="plus${item}" class="btn btn-danger plus">+</button>`;
            } else {
                div.innerHTML =
                    `<button id="${item}" class="btn btn-danger cart">Add to Cart <i class="ri-shopping-cart-line"></i></button>`;
                delete cart[item];
            }
        }
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    document.getElementById('cart').innerHTML = sum;
    console.log(cart);
}

// Handle minus button clicks
$('.divpr').on("click", "button.minus", function () {
    let a = this.id.slice(5);
    if (cart[a]) {
        cart[a][0] = Math.max(0, cart[a][0] - 1);
        document.getElementById('val' + a).innerHTML = cart[a][0];
        updateCart(cart);
    }
});

// Handle plus button clicks
$('.divpr').on("click", "button.plus", function () {
    let a = this.id.slice(4);
    if (cart[a]) {
        cart[a][0] += 1;
        document.getElementById('val' + a).innerHTML = cart[a][0];
        updateCart(cart);
    }
});
