from django.shortcuts import render,redirect
from Store.models import Contact,Product,Orders
from django.contrib import messages
from math import ceil
from django.conf import settings
import json
from django.http import HttpResponse


# Create your views here.
def index(request):
    allProds = []
    catprods = Product.objects.values('category','id')
    print(catprods)
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod= Product.objects.filter(category=cat)
        n=len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])

    params= {'allProds':allProds}

    return render(request,"index.html",params)

def contact(request):
    if request.method=="POST":  
        name=request.POST.get("name")
        email=request.POST.get("email")
        number=request.POST.get("phonenumber")
        desc=request.POST.get("desc")
        myquery=Contact(name=name,email=email,phonenumber=number,desc=desc)
        myquery.save()
        messages.info(request,'we will reply u soon...')
    return render(request,"contact.html")



def cart(request):
    return render(request,"cart.html")

def favorite(request):
    return render(request,"favorite.html")


def checkout(request):
    if not request.user.is_authenticated:
        messages.warning(request, "Login & Try Again")
        return redirect('/auth/login')

    # Initialize variables with default values
    items_json = ''
    name = ''
    amount = ''
    email = ''
    phone = ''
    table_number = 0

    if request.method == "POST":
        # Retrieve form data
        items_json = request.POST.get('itemsJson', '')
        name = request.POST.get('name', '')
        amount = request.POST.get('amt', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        table_number = request.POST.get('tableNumber', 0)  # Get table number from the form

        # Save the order
        order = Orders(
            items_json=items_json,
            name=name,
            amount=amount,
            email=email,
            phone=phone,
            table_number=table_number,  # Save table number
        )
        order.save()

        # Render the success page with the table number
        messages.success(request,"Your Order Is Been Successfull...")
        messages.error(request,"Wait for 20 minutes... Have Some Patience!")

    # You can add some code here to handle other HTTP methods (e.g., GET) if needed.
    return render(request, 'checkout.html')  # Render checkout page if not POST
