from django.shortcuts import render,redirect
from Store.models import Contact,Product
from django.contrib import messages
from math import ceil
from django.conf import settings
import json
from django.http import HttpResponse


# Create your views here.
def index(request):
    allProds = []
    catprods = Product.objects.values('category','id')
    print(catprods)
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod= Product.objects.filter(category=cat)
        n=len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])

    params= {'allProds':allProds}

    return render(request,"index.html",params)

def contact(request):
    if request.method=="POST":  
        name=request.POST.get("name")
        email=request.POST.get("email")
        number=request.POST.get("phonenumber")
        desc=request.POST.get("desc")
        myquery=Contact(name=name,email=email,phonenumber=number,desc=desc)
        myquery.save()
        messages.info(request,'we will reply u soon...')
    return render(request,"contact.html")


def checkout(request):
    return render(request,"checkout.html")

def cart(request):
    return render(request,"cart.html")

def favorite(request):
    return render(request,"favorite.html")