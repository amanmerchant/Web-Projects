from django.contrib import admin
from Store.models import Contact,Product

admin.site.register(Contact)
admin.site.register(Product)
# Register your models here.
