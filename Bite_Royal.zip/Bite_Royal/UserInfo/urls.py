from django.urls import path
from UserInfo import views

urlpatterns = [
    path('login/',views.handlelogin,name="handlelogin"),
    path('signup/',views.handlesignup,name="handlesignup"),
    path('logout/',views.handlelogout,name="handlelogout"),
]
